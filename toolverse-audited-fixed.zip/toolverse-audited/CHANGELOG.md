# Changelog

## Audit and fix package — 2026-10-22

- Reworked shared layout root detection for root and nested deployment paths.
- Added visible fallback messages when shared components fail to load.
- Synchronized `assets/js/manifest.js` fallback data with `data/tools.json`.
- Added conflict-aware draft restoration and an explicit Restore saved draft action.
- Replaced immediate delete actions with inline two-step confirmation.
- Guarded local/session storage access in admin flows.
- Improved image resizer error handling and object URL lifecycle.
- Improved typing practice accuracy comparison and live metric announcements.
- Made shared site branding/footer email use manifest settings where available.
- Removed the broken public sitemap admin link.
- Added missing page descriptions/Open Graph metadata and standardized asset version strings.
- Added audit, QA, and deployment documentation.
