# ToolVerse — InfinityFree Tools Hub

A static tools directory built with HTML, CSS and Vanilla JavaScript. No backend, database, external API or build step is required.

## Structure

- `index.html` — public responsive homepage
- `admin/admin.html` — local manifest editor
- `data/tools.json` — published source of truth
- `assets/css/` — styles
- `assets/js/` — homepage, admin and manifest validation
- `tools/` — independent HTML tools

## Local preview

Use a local static HTTP server (not `file://`) because the homepage loads `data/tools.json` using `fetch()`. For example, if Python is already installed, run `python -m http.server 8000` from this directory and open `http://localhost:8000`.

## InfinityFree deployment

1. Upload the contents of this project into `htdocs/`.
2. Make sure `data/tools.json` is uploaded as a valid JSON file.
3. Visit your HTTPS domain and test the homepage.
4. Open `admin/admin.html` to edit tools and sections.
5. Export `tools.json` from Import / Export.
6. Keep a backup of the current manifest.
7. Upload the exported file to `htdocs/data/tools.json`, replacing the old file.
8. Refresh the homepage. If the old version remains, use a hard refresh or clear cache.

## Add a tool

1. Upload the tool HTML to a path under `htdocs/tools/`, such as `tools/utilities/my-tool.html`.
2. Open `admin/admin.html` and choose Add tool.
3. Enter a unique ID, name, description, relative path and section.
4. Choose Draft until you have uploaded and checked the file; set Published when ready.
5. Export `tools.json` and upload it to `htdocs/data/tools.json`.

Paths must be relative HTML paths beginning with `tools/`. This project validates path syntax but cannot verify remote file existence without a backend.

## Add a section

Open Admin Studio → Manage sections → Add section. Save the section, assign tools to it, export the manifest and upload it. Creating a hosting folder alone does not register a section.

## Static-hosting limitations

- Browser JavaScript cannot securely authenticate an administrator or write directly to the hosting server.
- The admin editor keeps working data in the current page session; exporting the manifest is the publishing step. Download a backup before making major edits.
- The admin page is not protected by a server-side login. Do not treat its UI as private or store secrets in it. If you need secure remote administration and one-click publishing, a trusted backend or deployment workflow is required.
- The manifest is public and must contain public metadata only.

## Included example tools

- `tools/utilities/word-counter.html`
- `tools/utilities/calculator.html`
- `tools/study/typing-practice.html`
- `tools/image/image-resizer.html`

The image resizer is a functional browser-side example; it processes the selected image locally.


## Admin login

Default embedded browser-side credentials:
- Admin ID: `Admin@`
- Password: `Sourav@123`

After signing in, use **Admin security** to change the ID and password. Changed credentials are stored in that browser's local storage only. Clearing browser site data resets the credentials to the embedded defaults; another device uses the embedded defaults until changed there.

**Security warning:** This is not secure authentication. The default credentials are visible in the public JavaScript source, and client-side checks can be bypassed. Do not use this gate to protect private data or sensitive actions. Secure admin access and shared credentials across devices cannot be implemented reliably with HTML/CSS/Vanilla JS alone on static hosting.


## Shared header, footer and information pages

- `components/header.html` and `components/footer.html` are shared site-shell fragments.
- `assets/js/layout.js` loads those fragments into pages and provides theme, mobile navigation and site-name updates.
- Public pages include `about.html`, `contact.html`, `privacy-policy.html`, `terms.html`, `disclaimer.html`, `sitemap.html`, and `404.html`.
- Set `CONTACT_EMAIL` in `contact.html` to a real address before publishing. The form uses the visitor's email app; it does not send mail through a server.
- The shared fragments use `fetch()`, so preview via HTTP/HTTPS rather than opening files directly with `file://`.


## Latest responsive layout updates

- The public header is a rounded, compact horizontal bar. Admin is intentionally not linked anywhere in the public portal; open `/admin/admin.html` directly.
- Search is placed immediately below the header; entering one word filters results live.
- Category chips remain on one horizontally scrollable row on small screens.
- Tool cards have a full-width, high-visibility Open Tool action.
- Shared header/footer links are adjusted for nested tool pages.


## Performance fixes

- Removed the duplicate `data/tools.json` request from the shared layout loader.
- Fixed homepage startup bindings so the shared header's theme/menu controls do not throw errors and prevent tools from rendering.
- Admin page lives at `admin/admin.html`; no public header, hamburger, or footer admin link is included.
- Search field is compact and directly below the header.


## Admin hide/publish workflow

Tool and section edits now auto-save to a local browser draft and survive an admin page reload on that same browser. A tool set to `hidden` or a section with `visible: false` is excluded by the homepage renderer after the updated manifest is published. To publish to all visitors on static InfinityFree hosting, export `tools.json` from Admin > Import / Export and upload it to `htdocs/data/tools.json`. Client-side JavaScript cannot write the file to the server without a backend.


## Contact / content email

The configured content and support email is `souravyadav7480083@gmail.com`. The Contact page uses a `mailto:` flow, so it opens the visitor's email app; it does not silently send mail from the website.

## Tool page template

Copy `tools/template/tool-template.html` to a category folder such as `tools/utilities/my-tool.html`. Update the page title, visible heading, description, UI and `runTool()` logic. Then register the path in Admin > Manage Tools. The demo `runTool()` only echoes input; it is not a real tool until replaced.

## Cache policy

A root `.htaccess` file requests revalidation/no-storage for HTML, JSON, CSS and JavaScript. This depends on the hosting server allowing Apache `mod_headers`. Asset links also use a version query (`v=20261022-5`). After upload, replace all old files in `htdocs/` (do not upload the ZIP itself), especially `index.html`, `assets/`, `components/`, `data/tools.json`, and `admin/admin.html`. If the host does not permit these headers, query-versioned assets still help with CSS/JS cache; HTML may require a browser/hosting cache purge.

## Admin Studio redesign (2026-10-22)
- Rebuilt tool and section editing as inline full-page forms; no modal dialogs or confirmation pop-ups.
- Reworked mobile/tablet layout, sidebar navigation, action wrapping, and touch-friendly button sizing.
- Added an explicit publishing state area and clearer separation between a tool's `published` status and publishing the JSON to InfinityFree.
- Added a local-draft discard action. Static hosting still requires exporting `tools.json` and uploading it to `htdocs/data/tools.json`; browser JavaScript cannot publish server files by itself.
