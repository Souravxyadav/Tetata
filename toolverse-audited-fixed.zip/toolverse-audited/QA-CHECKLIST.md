# ToolVerse Admin Studio QA Checklist

## Automated checks completed for this package
- [x] Admin JavaScript parses with Node.js.
- [x] Manifest JSON parses.
- [x] Tool and section IDs are unique.
- [x] Every tool references an existing section.
- [x] Every registered tool HTML path exists.
- [x] Admin editor uses inline full-page sections, not `<dialog>` elements.
- [x] No `showModal()`, `confirm()`, or `alert()` calls remain in admin JavaScript.
- [x] Shared CSS/JS cache version updated to `20261022-4`.

## Manual checks to perform after uploading to InfinityFree
- [ ] Sign in and navigate through all sidebar sections on desktop and mobile.
- [ ] Add, edit, and delete a tool; test all action buttons at narrow screen widths.
- [ ] Add, edit, hide/show, and delete an unassigned section.
- [ ] Change a tool status and verify the public site after exporting and uploading `data/tools.json`.
- [ ] Export, import, and restore a backup manifest.
- [ ] Test contact email and site settings on the live site.

## Hosting limitation
This is a static HTML/CSS/Vanilla JavaScript site. Drafts are stored in the current browser. The `published` status controls whether a tool is included in the public directory; it does not upload files. To make changes live for all visitors, export `tools.json` and upload it to `htdocs/data/tools.json` in InfinityFree File Manager. Live-host testing has not been performed here.
