# ToolVerse Deployment Guide — InfinityFree

## Upload the website

1. Extract the complete ZIP on your computer.
2. Open InfinityFree File Manager or connect through FTP.
3. Open the website's `htdocs/` directory.
4. Upload the contents of the extracted `toolverse-audited/` folder into `htdocs/`. Do not upload only the ZIP file.
5. Preserve the folder structure, especially `assets/`, `components/`, `data/`, `admin/`, and `tools/`.
6. Keep a backup of the current site before replacing files.

## Publish tool metadata

1. Open `https://YOUR-DOMAIN/admin/admin.html` after uploading.
2. Sign in using the credentials configured in this browser. The default client-side credentials in the source are `Admin@` and `Sourav@123`; change them for convenience, but remember that browser-side credentials are not secure access control.
3. Add/edit tools and sections. These changes are saved in this browser only.
4. Open **Publish Changes** and fix any validation errors.
5. Export `tools.json`.
6. In File Manager, back up and replace `htdocs/data/tools.json` with the exported file.
7. Open the homepage in a fresh/private browser session and verify the new tool cards, categories, and links.

## Add a new tool HTML file

1. Create the HTML tool page using `tools/template/tool-template.html` as a starter.
2. Replace demo `runTool()` logic with the real tool implementation.
3. Upload the completed file into an appropriate folder under `htdocs/tools/`.
4. Register its relative path in Admin Studio, for example `tools/utilities/my-tool.html`.
5. Validate and export the manifest, then upload the JSON to `htdocs/data/tools.json`.
6. Test the tool page directly and through its homepage card.

## Cache troubleshooting

- Asset references use the `20261022-5` version query.
- `.htaccess` requests revalidation for HTML, JSON, CSS, and JS if the host permits the directives.
- If the site appears stale, hard-refresh the page, test in a private window, confirm the latest files exist in `htdocs/`, and verify `data/tools.json` directly.
- Do not assume `.htaccess` directives are supported until tested on the live host.

## Post-deployment smoke test

- Open homepage and confirm tools load.
- Test search, category filters, sort, and reset.
- Open Word Counter, Calculator, Typing Practice, and Image Resizer.
- Test header/footer links from root and nested tool pages.
- Open Admin Studio and test add/edit, draft save/recovery, import/export, and validation.
- Confirm changes appear publicly only after replacing `data/tools.json`.
- Check the browser console and network tab for missing assets or failed requests.

## Rollback

Before publishing a new manifest, download a copy of the current `htdocs/data/tools.json`. If the update fails, restore that backup. Keep a complete backup of the previous site files before a full deployment replacement.
