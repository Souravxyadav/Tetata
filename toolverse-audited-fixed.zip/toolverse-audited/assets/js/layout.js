(function () {
  "use strict";
  const $ = (selector, scope = document) => scope.querySelector(selector);

  function getSiteRoot() {
    const script = Array.from(document.scripts).find((item) => /(?:^|\/)assets\/js\/layout\.js(?:\?|$)/.test(item.src));
    if (script) {
      const scriptUrl = new URL(script.src, window.location.href);
      const suffix = "/assets/js/layout.js";
      if (scriptUrl.pathname.endsWith(suffix)) {
        const rootPath = scriptUrl.pathname.slice(0, -suffix.length) || "";
        return new URL((rootPath || "") + "/", scriptUrl.origin);
      }
    }
    const path = window.location.pathname;
    const toolsIndex = path.indexOf("/tools/");
    if (toolsIndex >= 0) return new URL(path.slice(0, toolsIndex + 1), window.location.origin);
    return new URL("./", window.location.href);
  }

  const siteRoot = getSiteRoot();
  const rootHref = (path) => new URL(String(path || "").replace(/^\/+/, ""), siteRoot).href;

  function theme() {
    let saved = "system";
    try { saved = localStorage.getItem("toolhub-theme") || "system"; } catch (_) {}
    const resolved = saved === "system"
      ? (window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark")
      : saved;
    document.documentElement.dataset.theme = ["light", "dark"].includes(resolved) ? resolved : "dark";
    document.querySelectorAll("[data-theme-toggle]").forEach((button) => {
      button.setAttribute("aria-label", `Theme: ${saved}. Change theme`);
    });
  }

  function setTheme() {
    let current = "system";
    try { current = localStorage.getItem("toolhub-theme") || "system"; } catch (_) {}
    const next = current === "system" ? "dark" : current === "dark" ? "light" : "system";
    try { localStorage.setItem("toolhub-theme", next); } catch (_) {}
    theme();
  }

  function resolveComponentLinks(host) {
    host.querySelectorAll("a[href]").forEach((anchor) => {
      const href = (anchor.getAttribute("href") || "").trim();
      if (!href || /^(?:[a-z][a-z\d+.-]*:|\/\/|#)/i.test(href)) return;
      anchor.href = rootHref(href);
    });
    host.querySelectorAll("[data-site-asset]").forEach((node) => {
      const value = node.getAttribute("data-site-asset");
      if (value && node.hasAttribute("src")) node.src = rootHref(value);
    });
  }

  async function insert(selector, path, fallbackLabel) {
    const host = $(selector);
    if (!host) return;
    try {
      const response = await fetch(rootHref(path), { cache: "no-cache" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      host.innerHTML = await response.text();
      resolveComponentLinks(host);
    } catch (_) {
      const fallback = document.createElement("p");
      fallback.className = "notice notice-error";
      fallback.setAttribute("role", "status");
      fallback.textContent = `${fallbackLabel} could not be loaded. Refresh the page or check the website files.`;
      host.replaceChildren(fallback);
    }
  }

  document.addEventListener("DOMContentLoaded", async () => {
    theme();
    await Promise.all([
      insert("[data-layout-header]", "components/header.html", "Website header"),
      insert("[data-layout-footer]", "components/footer.html", "Website footer")
    ]);
    try {
      const response = await fetch(rootHref("data/tools.json"), { cache: "no-cache" });
      if (response.ok) {
        const manifest = await response.json();
        const site = manifest && manifest.site ? manifest.site : {};
        document.querySelectorAll("[data-site-name]").forEach((node) => { node.textContent = site.name || "ToolVerse"; });
        document.querySelectorAll("[data-footer-description]").forEach((node) => { node.textContent = site.footerDescription || "A practical collection of tools for everyday work."; });
        document.querySelectorAll("[data-site-email]").forEach((node) => {
          const email = String(site.contactEmail || "").trim();
          if (email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            node.href = `mailto:${email}`;
            if (node.hasAttribute("data-email-label")) node.textContent = email;
          }
        });
      }
    } catch (_) { /* Shared layout remains usable if optional site metadata is unavailable. */ }
    document.querySelectorAll("[data-theme-toggle]").forEach((button) => button.addEventListener("click", setTheme));
    document.querySelectorAll("[data-menu-toggle]").forEach((button) => button.addEventListener("click", () => {
      const nav = $("[data-mobile-nav]");
      if (!nav) return;
      const opening = nav.hidden;
      nav.hidden = !opening;
      button.setAttribute("aria-expanded", String(opening));
      button.setAttribute("aria-label", opening ? "Close navigation" : "Open navigation");
      button.textContent = opening ? "×" : "☰";
    }));
    document.querySelectorAll("[data-current-year]").forEach((node) => { node.textContent = new Date().getFullYear(); });
  });
})();
