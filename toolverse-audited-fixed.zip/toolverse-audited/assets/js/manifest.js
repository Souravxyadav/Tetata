(function(global){
  "use strict";
  const DEFAULT_MANIFEST = {
    schemaVersion: 1,
    site: { name: "ToolVerse", tagline: "All your useful tools in one clean, simple place.", defaultTheme: "system", footerDescription: "A practical collection of tools for everyday work.", contactEmail: "souravyadav7480083@gmail.com" },
    sections: [
      { id: "pdf", name: "PDF Tools", description: "Work with PDF documents", icon: "file-text", order: 1, visible: true },
      { id: "study", name: "Study", description: "Tools for learning and productivity", icon: "graduation-cap", order: 2, visible: true },
      { id: "utilities", name: "Utilities", description: "Useful everyday tools", icon: "wrench", order: 3, visible: true },
      { id: "image", name: "Image Tools", description: "Resize and manage images", icon: "image", order: 4, visible: true }
    ],
    tools: [
      { id: "word-counter", name: "Word Counter", description: "Count words, characters and paragraphs in your text.", path: "tools/utilities/word-counter.html", sectionId: "utilities", icon: "file-text", tags: ["text", "writing", "words"], status: "published", featured: true, isNew: true, order: 1, createdAt: "2026-10-22" },
      { id: "smart-calculator", name: "Smart Calculator", description: "A quick calculator for everyday calculations.", path: "tools/utilities/calculator.html", sectionId: "utilities", icon: "calculator", tags: ["math", "numbers"], status: "published", featured: false, isNew: false, order: 2, createdAt: "2026-10-21" },
      { id: "typing-practice", name: "Typing Practice", description: "Practice typing and track your accuracy.", path: "tools/study/typing-practice.html", sectionId: "study", icon: "keyboard", tags: ["typing", "study", "keyboard"], status: "published", featured: true, isNew: false, order: 1, createdAt: "2026-10-20" },
      { id: "image-resizer", name: "Image Resizer", description: "Resize images directly in your browser.", path: "tools/image/image-resizer.html", sectionId: "image", icon: "image", tags: ["image", "resize", "photo"], status: "published", featured: false, isNew: true, order: 1, createdAt: "2026-10-19" }
    ]
  };
  const clone = value => JSON.parse(JSON.stringify(value));
  function validateManifest(data) {
    const errors = [];
    if (!data || typeof data !== "object" || Array.isArray(data)) return ["Manifest must be a JSON object."];
    if (data.schemaVersion !== 1) errors.push("schemaVersion must be 1.");
    if (!data.site || typeof data.site !== "object") errors.push("site settings are required.");
    if (!Array.isArray(data.sections)) errors.push("sections must be an array.");
    if (!Array.isArray(data.tools)) errors.push("tools must be an array.");
    if (errors.length) return errors;
    if (!String(data.site.name || "").trim()) errors.push("Website name is required.");
    if (!["system","dark","light"].includes(data.site.defaultTheme || "system")) errors.push("Invalid default theme.");
    const sectionIds = new Set();
    data.sections.forEach((section, i) => {
      if (!section || typeof section !== "object") { errors.push(`Section ${i+1} is invalid.`); return; }
      if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(section.id || "")) errors.push(`Section ${i+1} has an invalid ID.`);
      if (sectionIds.has(section.id)) errors.push(`Duplicate section ID: ${section.id}.`);
      sectionIds.add(section.id);
      if (!String(section.name || "").trim()) errors.push(`Section ${section.id || i+1} needs a name.`);
      if (!Number.isInteger(Number(section.order)) || Number(section.order) < 0) errors.push(`Section ${section.id || i+1} has invalid order.`);
    });
    const toolIds = new Set();
    data.tools.forEach((tool, i) => {
      if (!tool || typeof tool !== "object") { errors.push(`Tool ${i+1} is invalid.`); return; }
      if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(tool.id || "")) errors.push(`Tool ${i+1} has an invalid ID.`);
      if (toolIds.has(tool.id)) errors.push(`Duplicate tool ID: ${tool.id}.`);
      toolIds.add(tool.id);
      if (!String(tool.name || "").trim()) errors.push(`Tool ${tool.id || i+1} needs a name.`);
      if (!String(tool.description || "").trim()) errors.push(`Tool ${tool.id || i+1} needs a description.`);
      if (!sectionIds.has(tool.sectionId)) errors.push(`Tool ${tool.id || i+1} references missing section "${tool.sectionId}".`);
      if (!isSafeToolPath(tool.path)) errors.push(`Tool ${tool.id || i+1} has an unsafe path. Use tools/folder/file.html.`);
      if (!["published","draft","hidden"].includes(tool.status)) errors.push(`Tool ${tool.id || i+1} has invalid status.`);
      if (!Number.isInteger(Number(tool.order)) || Number(tool.order) < 0) errors.push(`Tool ${tool.id || i+1} has invalid order.`);
      if (!Array.isArray(tool.tags)) errors.push(`Tool ${tool.id || i+1} tags must be an array.`);
    });
    return errors;
  }
  function isSafeToolPath(path) {
    if (typeof path !== "string" || !path || path.length > 240) return false;
    if (path.includes("\\") || path.includes("?") || path.includes("#") || path.includes(":")) return false;
    if (path.startsWith("/") || path.startsWith("//")) return false;
    const parts = path.split("/");
    if (parts[0] !== "tools" || parts.some(p => !p || p === "." || p === "..")) return false;
    return /\.html?$/i.test(path);
  }
  global.ToolHubManifest = { DEFAULT_MANIFEST, clone, validateManifest, isSafeToolPath };
})(window);
