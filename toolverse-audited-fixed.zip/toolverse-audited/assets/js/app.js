(function(){
"use strict";
const $ = (s,root=document)=>root.querySelector(s);
const $$ = (s,root=document)=>Array.from(root.querySelectorAll(s));
const icons = {"file-text":"▤",calculator:"＋",keyboard:"⌨",image:"▧",wrench:"⌘",code:"</>", "graduation-cap":"⌑",clock:"◷",file:"▤",sparkles:"✳"};
const colorNames=["red","yellow","green","blue"];
let manifest=null, activeSections=new Set(), query="";
const root=document.documentElement;
function applyTheme(choice){
  const saved=choice||localStorage.getItem("toolhub-theme")||"system";
  const resolved=saved==="system"?(matchMedia("(prefers-color-scheme: light)").matches?"light":"dark"):saved;
  root.dataset.theme=resolved;
  const button=$("[data-theme-toggle]"); if(button) button.setAttribute("aria-label",`Theme: ${saved}. Change theme`);
}
function el(tag,className,text){const n=document.createElement(tag);if(className)n.className=className;if(text!==undefined)n.textContent=text;return n}
function sortSections(){return [...manifest.sections].filter(s=>s.visible).sort((a,b)=>Number(a.order)-Number(b.order)||a.name.localeCompare(b.name))}
function visibleTools(){return manifest.tools.filter(t=>t.status==="published"&&manifest.sections.some(s=>s.id===t.sectionId&&s.visible))}
function makeChip(section,count,selected){
  const b=el("button","filter-chip"+(selected?" selected":""));b.type="button";b.dataset.section=section?section.id:"all";b.setAttribute("aria-pressed",String(selected));
  b.append(document.createTextNode((section?icons[section.icon]||"✳":"✦")+" "+(section?section.name:"All tools")));
  const c=el("span","filter-count",String(count));b.append(c);b.addEventListener("click",()=>{const id=b.dataset.section;if(id==="all")activeSections.clear();else{activeSections.delete("all");activeSections.has(id)?activeSections.delete(id):activeSections.add(id);if(!activeSections.size)activeSections.add("all")}renderFilters();renderTools()});return b;
}
function renderFilters(){
 const host=$("#category-filters");host.replaceChildren();activeSections= new Set([...activeSections].filter(id=>id==="all"||sortSections().some(s=>s.id===id)));if(!activeSections.size)activeSections.add("all");
 host.append(makeChip(null,visibleTools().length,activeSections.has("all")));
 sortSections().forEach(s=>host.append(makeChip(s,visibleTools().filter(t=>t.sectionId===s.id).length,activeSections.has(s.id))));
 $("#category-count").textContent=`${sortSections().length} categories`;
}
function iconClass(t){return colorNames[(t.id.length+t.name.length)%colorNames.length]}
function makeCard(tool){
 const card=el("article","tool-card");card.dataset.toolId=tool.id;
 const top=el("div","tool-card-top");const icon=el("div",`tool-icon ${iconClass(tool)}`,icons[tool.icon]||"✳");icon.setAttribute("aria-hidden","true");top.append(icon);
 const badges=el("div","tool-badges");if(tool.isNew)badges.append(el("span","mini-badge new","New"));if(tool.featured)badges.append(el("span","mini-badge featured","Featured"));top.append(badges);
 const title=el("h3","",tool.name);const desc=el("p","",tool.description);const section=manifest.sections.find(s=>s.id===tool.sectionId);
 const bottom=el("div","tool-card-bottom");bottom.append(el("span","tool-category",section?section.name:"Tools"));
 const link=el("a","open-tool","Open tool");link.href=tool.path;link.append(document.createTextNode(" "));link.append(el("span","","↗"));link.setAttribute("aria-label",`Open ${tool.name}`);bottom.append(link);
 card.append(top,title,desc,bottom);return card;
}
function getResults(){
 const terms=query.toLocaleLowerCase().trim().split(/\s+/).filter(Boolean);
 let list=visibleTools().filter(t=>{
  const section=manifest.sections.find(s=>s.id===t.sectionId);
  if(!activeSections.has("all")&&!activeSections.has(t.sectionId))return false;
  const hay=[t.name,t.description,t.sectionId,section&&section.name,...t.tags].join(" ").toLocaleLowerCase();
  return terms.every(term=>hay.includes(term));
 });
 const sort=$("#sort-tools").value;
 if(sort==="name")list.sort((a,b)=>a.name.localeCompare(b.name));
 else if(sort==="newest")list.sort((a,b)=>(b.createdAt||"").localeCompare(a.createdAt||"")||a.name.localeCompare(b.name));
 else list.sort((a,b)=>Number(b.featured)-Number(a.featured)||Number(a.order)-Number(b.order)||a.name.localeCompare(b.name));
 return list;
}
function renderTools(){
 if(!manifest)return;const host=$("#tools-container"),results=getResults();host.replaceChildren();
 const grouped=!query.trim()&&activeSections.has("all")&&$("#sort-tools").value==="custom";
 if(grouped){
  const groups=sortSections().map(s=>({section:s,tools:results.filter(t=>t.sectionId===s.id)})).filter(g=>g.tools.length);
  groups.forEach(g=>{
   const group=el("section","tool-group");const head=el("div","group-heading");const h=el("h3","",g.section.name);const count=el("span","muted small-text",`${g.tools.length} ${g.tools.length===1?"tool":"tools"}`);head.append(h,count);group.append(head);
   const grid=el("div","tools-container group-grid");g.tools.forEach(t=>grid.append(makeCard(t)));group.append(grid);host.append(group);
  });
 }else results.forEach(t=>host.append(makeCard(t)));
 $("#empty-state").hidden=results.length!==0;host.hidden=results.length===0;
 $("#results-title").textContent=query||!activeSections.has("all")?"Search results":"Explore tools";
 $("#filter-summary").textContent=`Showing ${results.length} of ${visibleTools().length} published tools`;
 $("#tool-count").textContent=`${visibleTools().length} published ${visibleTools().length===1?"tool":"tools"}`;
 $("#clear-search").hidden=!query;
}
async function load(){
 applyTheme();
 $("#tool-search").addEventListener("input",e=>{query=e.target.value;renderTools()});
 $("#clear-search").addEventListener("click",()=>{$("#tool-search").value="";query="";$("#tool-search").focus();renderTools()});
 $("#sort-tools").addEventListener("change",renderTools);
 $("#reset-filters").addEventListener("click",()=>{query="";$("#tool-search").value="";activeSections=new Set(["all"]);$("#sort-tools").value="custom";renderFilters();renderTools()});
 document.addEventListener("keydown",e=>{if(e.key==="/"&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)&&!e.ctrlKey&&!e.metaKey){e.preventDefault();$("#tool-search").focus()}if(e.key==="Escape"&&document.activeElement===$("#tool-search")){$("#tool-search").value="";query="";renderTools()}});
 try{
  const response=await fetch("data/tools.json",{cache:"no-store"});
  if(!response.ok)throw new Error(`Could not load data/tools.json (HTTP ${response.status}).`);
  const data=await response.json();
  const errors=window.ToolHubManifest?window.ToolHubManifest.validateManifest(data):[];
  if(errors.length)throw new Error(errors.slice(0,3).join(" "));
  manifest=data;
  document.querySelectorAll("[data-site-name]").forEach(node=>node.textContent=data.site.name||"ToolVerse");
  document.title=`${data.site.name} — All your tools in one place`;
  $("#site-tagline").textContent=data.site.tagline||"Useful tools for everyday work.";
  document.querySelectorAll("[data-footer-description]").forEach(node=>node.textContent=data.site.footerDescription||"A practical collection of tools for everyday work.");
  applyTheme(data.site.defaultTheme);
  activeSections=new Set(["all"]);renderFilters();renderTools();
 }catch(error){
  $("#tools-container").hidden=true;$("#load-error").hidden=false;
  $("#load-error").textContent=`Tools could not be loaded. ${error.message} Check that data/tools.json exists and contains valid JSON, then refresh.`;
  $("#tool-count").textContent="Tools unavailable";
  $("#empty-state").hidden=true;
 }
}
document.addEventListener("DOMContentLoaded",load);
})();
