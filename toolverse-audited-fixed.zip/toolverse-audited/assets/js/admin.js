(function(){
"use strict";
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const API=window.ToolHubManifest;
const DEFAULT_ADMIN_ID="Admin@";
const DEFAULT_ADMIN_PASSWORD="Sourav@123";
const CREDENTIALS_KEY="toolhub-admin-credentials-v1";
const MANIFEST_DRAFT_KEY="toolhub-manifest-draft-v2";
let data=API.clone(API.DEFAULT_MANIFEST),changedAt=[],activeView="overview",hostedManifestString=null;
function storageGet(storage,key){try{return storage.getItem(key)}catch(_){return null}}
function storageSet(storage,key,value){try{storage.setItem(key,value);return true}catch(_){return false}}
function storageRemove(storage,key){try{storage.removeItem(key);return true}catch(_){return false}}
function getCredentials(){
 try { const saved=JSON.parse(storageGet(localStorage,CREDENTIALS_KEY)||"null"); if(saved&&typeof saved.id==="string"&&typeof saved.password==="string")return saved; } catch(_){}
 return {id:DEFAULT_ADMIN_ID,password:DEFAULT_ADMIN_PASSWORD};
}
function saveCredentials(id,password){return storageSet(localStorage,CREDENTIALS_KEY,JSON.stringify({id,password}));}

const icons={"file-text":"▤",calculator:"＋",keyboard:"⌨",image:"▧",wrench:"⌘",code:"</>","graduation-cap":"⌑",clock:"◷",file:"▤",sparkles:"✳"};
function toast(message,type="success"){const t=document.createElement("div");t.className=`toast ${type}`;t.textContent=message;$("#toast-region").append(t);setTimeout(()=>t.remove(),3500)}
function notice(message,type=""){const n=$("#admin-notice");n.textContent=message;n.className=`notice ${type}`;n.hidden=false}
function hideNotice(){$("#admin-notice").hidden=true}
function esc(value){return String(value??"")}
function slug(value){return String(value||"").normalize("NFKD").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,80)}
function sortByOrder(items){return [...items].sort((a,b)=>Number(a.order)-Number(b.order)||String(a.name).localeCompare(String(b.name)))}
function markChange(item){changedAt.unshift({id:item.id,name:item.name,type:item.sectionId?"Tool":"Section",time:new Date().toLocaleTimeString()});changedAt=changedAt.slice(0,8)}
function saveDraft(){
 if(storageSet(localStorage,MANIFEST_DRAFT_KEY,JSON.stringify({savedAt:Date.now(),baseManifest:hostedManifestString,manifest:data})))return true;toast("Could not save local draft. Export a backup now; browser storage may be disabled or full.","error");return false
}
function changed(message){saveDraft();hideNotice();renderAll();toast(message)}
function statusPill(status){const e=document.createElement("span");e.className=`status-pill ${status}`;e.textContent=status;return e}
function make(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e}
function closeEditor(){
  const destination=activeView==="editor-section"?"sections":"tools";
  $("#tool-dialog").hidden=true;$("#section-dialog").hidden=true;
  setView(destination);
}
function showEditor(kind){
  activeView=kind==="tool"?"editor-tool":"editor-section";
  $$(".admin-view").forEach(p=>p.classList.remove("active"));
  $("#tool-dialog").hidden=kind!=="tool";$("#section-dialog").hidden=kind!=="section";
  $("#quick-add-tool").hidden=true;
  $("#view-title").textContent=kind==="tool"?$("#tool-dialog-title").textContent:$("#section-dialog-title").textContent;
  $("#view-subtitle").textContent=kind==="tool"?"Complete the details below, then save your changes.":"Edit category details below. No pop-ups; this is a full-page editor.";
  window.scrollTo({top:0,behavior:"smooth"});
}
function setView(view){
 activeView=view;$$(".sidebar-link").forEach(b=>b.classList.toggle("active",b.dataset.view===view));$$(".admin-view").forEach(p=>p.classList.toggle("active",p.dataset.panel===view));
 const titles={"editor-tool":["Tool editor","Complete the details below, then save your changes."],"editor-section":["Section editor","Edit category details below."],overview:["Overview","Manage your tools directory."],tools:["Manage tools","Add, edit and organize your registered tools."],sections:["Manage sections","Create and organize homepage categories."],settings:["Site settings","Customize your website identity and default theme."],security:["Admin security","Change the admin ID and password."],publish:["Import / Export","Validate and publish your static configuration."]};
 $("#view-title").textContent=titles[view][0];$("#view-subtitle").textContent=titles[view][1];$("#quick-add-tool").hidden=!(view==="overview"||view==="tools");
 if(view==="publish")renderPublish();if(view==="security")fillSecurityForm();$("#tool-dialog").hidden=true;$("#section-dialog").hidden=true;
}
function renderOverview(){
 $("#stat-total").textContent=data.tools.length;$("#stat-published").textContent=data.tools.filter(t=>t.status==="published").length;$("#stat-drafts").textContent=data.tools.filter(t=>t.status!=="published").length;$("#stat-sections").textContent=data.sections.length;
 const host=$("#recent-tools");host.replaceChildren();
 const recent=changedAt.length?changedAt.slice(0,5):data.tools.slice(0,5).map(t=>({id:t.id,name:t.name,type:"Tool",time:"In manifest"}));
 if(!recent.length){host.append(make("p","muted small-text","No entries yet. Add your first tool to get started."));return}
 recent.forEach(item=>{const row=make("div","recent-item"),ico=make("div","recent-icon","✳"),main=make("div","recent-main"),strong=make("strong","",item.name),small=make("small","",`${item.type} · ${item.time}`);main.append(strong,small);row.append(ico,main);const entry=data.tools.find(t=>t.id===item.id);if(entry)row.append(statusPill(entry.status));host.append(row)});
}
function renderTools(){
 const host=$("#tools-table-wrap");host.replaceChildren();const q=$("#admin-tool-search").value.trim().toLowerCase(),status=$("#admin-status-filter").value;
 const list=sortByOrder(data.tools).filter(t=>(status==="all"||t.status===status)&&[t.name,t.description,t.id,t.path,...(t.tags||[])].join(" ").toLowerCase().includes(q));
 if(!list.length){host.append(make("div","empty-state","No matching tools. Add a tool or change your filters."));return}
 const table=make("table","admin-table"),thead=document.createElement("thead"),hr=document.createElement("tr");
 ["TOOL","SECTION","STATUS","ORDER","ACTIONS"].forEach(x=>hr.append(make("th","",x)));thead.append(hr);const tbody=document.createElement("tbody");
 list.forEach(t=>{
  const tr=document.createElement("tr"),td1=document.createElement("td"),group=make("div","table-tool"),ico=make("span","table-tool-icon",icons[t.icon]||"✳"),info=make("div"),name=make("strong","",t.name),desc=make("small","",t.path);info.append(name,desc);group.append(ico,info);td1.append(group);
  const sec=make("td","",data.sections.find(s=>s.id===t.sectionId)?.name||"Missing section"),stat=document.createElement("td");stat.append(statusPill(t.status));const order=make("td","",String(t.order)),actions=make("td"),actionBox=make("div","table-actions");
  const open=document.createElement("a");open.className="mini-action";open.textContent="Open";open.href="../"+t.path;open.target="_blank";open.rel="noopener";open.setAttribute("aria-label",`Open ${t.name} in a new tab`);
  const edit=make("button","mini-action","Edit");edit.type="button";edit.addEventListener("click",()=>openTool(t.id));
  const toggle=make("button","mini-action",t.status==="published"?"Hide":"Publish");toggle.type="button";toggle.addEventListener("click",()=>{t.status=t.status==="published"?"hidden":"published";markChange(t);changed(`"${t.name}" is now ${t.status}. Local draft saved. Export tools.json and upload it to publish this change on the live website.`)});
  const del=make("button","mini-action","Delete");del.type="button";del.addEventListener("click",()=>{if(del.dataset.confirm==="yes"){deleteTool(t.id);return}del.dataset.confirm="yes";del.textContent="Confirm delete?";del.setAttribute("aria-label",`Confirm deleting ${t.name}`);notice(`Click “Confirm delete?” again to remove “${t.name}”. No changes are made yet.`);setTimeout(()=>{if(del.isConnected){del.dataset.confirm="no";del.textContent="Delete";del.removeAttribute("aria-label");}},5000)});
  actionBox.append(open,edit,toggle,del);actions.append(actionBox);tr.append(td1,sec,stat,order,actions);tbody.append(tr);
 });table.append(thead,tbody);host.append(table);
}
function renderSections(){
 const host=$("#sections-list");host.replaceChildren();
 sortByOrder(data.sections).forEach(s=>{
  const row=make("article","section-admin-item"),ico=make("div","section-admin-icon",icons[s.icon]||"✳"),main=make("div","section-admin-main"),name=make("strong","",s.name),desc=make("p","",s.description||"No description"),count=make("small","",`${data.tools.filter(t=>t.sectionId===s.id).length} tool(s) · ID: ${s.id}`);main.append(name,desc,count);
  const actions=make("div","section-admin-actions"),edit=make("button","mini-action","Edit"),vis=make("button","mini-action",s.visible?"Hide":"Show"),del=make("button","mini-action","Delete");
  edit.type=vis.type=del.type="button";edit.addEventListener("click",()=>openSection(s.id));vis.addEventListener("click",()=>{s.visible=!s.visible;markChange(s);changed(`Section "${s.name}" is now ${s.visible?"visible":"hidden"}. Local draft saved. Export tools.json and upload it to publish this change on the live website.`)});del.addEventListener("click",()=>{if(del.dataset.confirm==="yes"){deleteSection(s.id);return}del.dataset.confirm="yes";del.textContent="Confirm delete?";notice(`Click “Confirm delete?” again to remove section “${s.name}”. Assigned sections cannot be deleted.`);setTimeout(()=>{if(del.isConnected){del.dataset.confirm="no";del.textContent="Delete";}},5000)});actions.append(edit,vis,del);row.append(ico,main,actions);host.append(row);
 });
 if(!data.sections.length)host.append(make("div","empty-state","No sections yet. Create a section to organize tools."));
}
function fillSettings(){const f=$("#settings-form");f.elements.name.value=data.site.name||"";f.elements.tagline.value=data.site.tagline||"";f.elements.defaultTheme.value=data.site.defaultTheme||"system";f.elements.footerDescription.value=data.site.footerDescription||"";f.elements.contactEmail.value=data.site.contactEmail||"souravyadav7480083@gmail.com"}
function fillSecurityForm(){
 const f=$("#security-form");if(!f)return;const creds=getCredentials();
 f.elements.adminId.value=creds.id;f.elements.newPassword.value="";f.elements.confirmPassword.value="";f.elements.currentPassword.value="";$("#security-error").hidden=true;
}
function handleSecuritySubmit(e){
 e.preventDefault();const f=e.currentTarget,err=$("#security-error"),creds=getCredentials();
 const id=f.elements.adminId.value.trim(),password=f.elements.newPassword.value,confirmPassword=f.elements.confirmPassword.value,current=f.elements.currentPassword.value;
 err.hidden=true;
 if(current!==creds.password){err.textContent="Current password is incorrect.";err.hidden=false;return}
 if(id.length<3){err.textContent="Admin ID must contain at least 3 characters.";err.hidden=false;return}
 if(password.length<8){err.textContent="New password must be at least 8 characters.";err.hidden=false;return}
 if(password!==confirmPassword){err.textContent="New passwords do not match.";err.hidden=false;return}
 if(id===creds.id&&password===creds.password){err.textContent="Choose a different ID or password.";err.hidden=false;return}
 saveCredentials(id,password);storageRemove(sessionStorage,"toolhub-admin-unlocked");
 toast("Credentials updated in this browser. Sign in again to continue.");
 showAuth();
}
function renderPublish(){
 const errors=API.validateManifest(data),box=$("#validation-summary");box.replaceChildren();
 const draftRaw=localStorage.getItem(MANIFEST_DRAFT_KEY);let draftTime="No saved local draft";if(draftRaw){try{const parsed=JSON.parse(draftRaw);draftTime="Last saved: "+new Date(parsed.savedAt||Date.now()).toLocaleString("en-IN")}catch(_){draftTime="Local draft found"}}
 if($("#publish-draft-time"))$("#publish-draft-time").textContent=draftTime;
 if($("#publish-validation-state"))$("#publish-validation-state").textContent=errors.length?"Needs fixes":"Passed";
 if($("#publish-draft-state"))$("#publish-draft-state").textContent=draftRaw?"Draft saved":"No draft";
 const title=make("strong",errors.length?"invalid":"valid",errors.length?`${errors.length} validation issue(s) found`:"✓ Manifest validation passed");
 box.append(title);
 if(errors.length){const ul=document.createElement("ul");errors.forEach(e=>ul.append(make("li","",e)));box.append(ul)}
 else box.append(make("p","",`${data.tools.length} tool entries and ${data.sections.length} sections are ready to export.`));
 $("#json-preview").textContent=JSON.stringify(data,null,2);
}
function renderAll(){renderOverview();renderTools();renderSections();fillSettings();if(activeView==="publish")renderPublish()}
function fillSectionOptions(selected=""){
 const select=$("#tool-form").elements.sectionId;select.replaceChildren();
 sortByOrder(data.sections).forEach(s=>{const opt=document.createElement("option");opt.value=s.id;opt.textContent=s.name;select.append(opt)});
 if(selected)select.value=selected;
}
function populatePathChoices(currentPath=""){
 const select=$("#tool-path-choice"),custom=$("#tool-custom-path");
 select.replaceChildren();
 const paths=[...new Set(["tools/utilities/word-counter.html","tools/utilities/calculator.html","tools/study/typing-practice.html","tools/image/image-resizer.html",...data.tools.map(t=>t.path)].filter(Boolean))].sort();
 paths.forEach(path=>{const opt=document.createElement("option");opt.value=path;opt.textContent=path;select.append(opt)});
 const customOpt=document.createElement("option");customOpt.value="__custom__";customOpt.textContent="＋ Custom path…";select.append(customOpt);
 if(currentPath&&paths.includes(currentPath)){select.value=currentPath;custom.hidden=true;custom.required=false;custom.value=currentPath}
 else if(currentPath){select.value="__custom__";custom.hidden=false;custom.required=true;custom.value=currentPath}
 else {select.value=paths[0]||"__custom__";custom.hidden=select.value!=="__custom__";custom.required=!custom.hidden;custom.value=""}
}
function selectedToolPath(){
 const choice=$("#tool-path-choice").value;
 return choice==="__custom__"?$("#tool-custom-path").value.trim():choice;
}
function openTool(id){
 const f=$("#tool-form");f.reset();$("#tool-form-error").hidden=true;
 const t=data.tools.find(x=>x.id===id);$("#tool-dialog-title").textContent=t?"Edit tool":"Add tool";
 fillSectionOptions(t?t.sectionId:"");
 f.elements.originalId.value=t?t.id:"";f.elements.name.value=t?t.name:"";f.elements.id.value=t?t.id:"";f.elements.description.value=t?t.description:"";populatePathChoices(t?t.path:"");f.elements.icon.value=t?t.icon||"sparkles":"sparkles";f.elements.tags.value=t?(t.tags||[]).join(", "):"";f.elements.status.value=t?t.status:"published";f.elements.order.value=t?t.order:Math.max(0,...data.tools.map(x=>Number(x.order)||0))+1;f.elements.featured.checked=!!(t&&t.featured);f.elements.isNew.checked=!!(t&&t.isNew);
 f.elements.name.oninput=()=>{if(!f.elements.originalId.value||f.elements.id.dataset.edited!=="true")f.elements.id.value=slug(f.elements.name.value)};
 f.elements.id.oninput=()=>{f.elements.id.dataset.edited="true"};
 if(!data.sections.length){$("#tool-form-error").textContent="Create a section before adding a tool.";$("#tool-form-error").hidden=false}
 showEditor("tool");
}
function toolFormSubmit(e){
 e.preventDefault();const f=e.currentTarget,err=$("#tool-form-error");err.hidden=true;
 const original=f.elements.originalId.value,id=slug(f.elements.id.value),name=f.elements.name.value.trim(),path=selectedToolPath(),sectionId=f.elements.sectionId.value;
 const errors=[];
 if(!id||id!==f.elements.id.value)errors.push("ID must use lowercase letters, numbers and hyphens.");
 if(data.tools.some(t=>t.id===id&&t.id!==original))errors.push("That tool ID already exists.");
 if(!name)errors.push("Tool name is required.");
 if(!f.elements.description.value.trim())errors.push("Description is required.");
 if(!API.isSafeToolPath(path))errors.push("Path must be a safe relative HTML path under tools/, such as tools/utilities/my-tool.html.");
 if(!data.sections.some(s=>s.id===sectionId))errors.push("Choose a valid section.");
 if(!Number.isInteger(Number(f.elements.order.value))||Number(f.elements.order.value)<0)errors.push("Order must be a non-negative integer.");
 if(errors.length){err.textContent=errors.join(" ");err.hidden=false;return}
 const t={id,name,description:f.elements.description.value.trim(),path,sectionId,icon:f.elements.icon.value,tags:f.elements.tags.value.split(",").map(x=>x.trim()).filter(Boolean),status:f.elements.status.value,featured:f.elements.featured.checked,isNew:f.elements.isNew.checked,order:Number(f.elements.order.value),createdAt:(data.tools.find(x=>x.id===original)||{}).createdAt||new Date().toISOString().slice(0,10)};
 if(original){const idx=data.tools.findIndex(x=>x.id===original);data.tools[idx]=t}else data.tools.push(t);
 markChange(t);$("#tool-dialog").hidden=true;setView("tools");changed(original?"Tool updated in editor.":"Tool added to editor. Export the manifest to publish.");}
function openSection(id){
 const f=$("#section-form");f.reset();$("#section-form-error").hidden=true;const s=data.sections.find(x=>x.id===id);$("#section-dialog-title").textContent=s?"Edit section":"Add section";
 f.elements.originalId.value=s?s.id:"";f.elements.name.value=s?s.name:"";f.elements.id.value=s?s.id:"";f.elements.description.value=s?s.description||"":"";f.elements.icon.value=s?s.icon||"wrench":"wrench";f.elements.order.value=s?s.order:Math.max(0,...data.sections.map(x=>Number(x.order)||0))+1;f.elements.visible.checked=s?s.visible!==false:true;
 f.elements.name.oninput=()=>{if(!f.elements.originalId.value||f.elements.id.dataset.edited!=="true")f.elements.id.value=slug(f.elements.name.value)};f.elements.id.oninput=()=>f.elements.id.dataset.edited="true";showEditor("section");
}
function sectionFormSubmit(e){
 e.preventDefault();const f=e.currentTarget,err=$("#section-form-error");err.hidden=true;const original=f.elements.originalId.value,id=slug(f.elements.id.value),name=f.elements.name.value.trim(),errors=[];
 if(!id||id!==f.elements.id.value)errors.push("ID must use lowercase letters, numbers and hyphens.");
 if(data.sections.some(s=>s.id===id&&s.id!==original))errors.push("That section ID already exists.");
 if(!name)errors.push("Section name is required.");
 if(!Number.isInteger(Number(f.elements.order.value))||Number(f.elements.order.value)<0)errors.push("Order must be a non-negative integer.");
 if(errors.length){err.textContent=errors.join(" ");err.hidden=false;return}
 const s={id,name,description:f.elements.description.value.trim(),icon:f.elements.icon.value,order:Number(f.elements.order.value),visible:f.elements.visible.checked};
 if(original&&original!==id)data.tools.forEach(t=>{if(t.sectionId===original)t.sectionId=id});
 if(original){data.sections[data.sections.findIndex(x=>x.id===original)]=s}else data.sections.push(s);
 markChange(s);$("#section-dialog").hidden=true;setView("sections");changed(original?"Section updated; tool assignments preserved.":"Section added to editor.");
}
function deleteTool(id){const t=data.tools.find(x=>x.id===id);if(!t)return;data.tools=data.tools.filter(x=>x.id!==id);changed("Tool entry removed. Export the manifest to publish.");}
function deleteSection(id){const s=data.sections.find(x=>x.id===id);if(!s)return;const assigned=data.tools.filter(t=>t.sectionId===id);if(assigned.length){notice(`Cannot delete “${s.name}”: reassign or remove its ${assigned.length} assigned tool(s) first.`,"notice-error");return}data.sections=data.sections.filter(x=>x.id!==id);changed("Section removed from editor.");}
function download(filename,content,type="application/json"){const blob=new Blob([content],{type}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function exportManifest(){const errors=API.validateManifest(data);if(errors.length){renderPublish();notice("Fix validation errors before exporting.","notice-error");toast("Manifest has validation errors.","error");return}download("tools.json",JSON.stringify(data,null,2));toast("tools.json exported. Upload it to htdocs/data/tools.json.");}
async function importManifest(file){if(!file)return;try{const parsed=JSON.parse(await file.text()),errors=API.validateManifest(parsed);if(errors.length)throw new Error(errors.slice(0,5).join(" "));data=API.clone(parsed);changedAt=[];changed("Manifest imported and validated.");setView("overview")}catch(e){toast(`Import failed: ${e.message}`,"error")}finally{$("#import-json").value=""}}
async function init(){
 const auth=$("#admin-auth"),app=$("#admin-app"),authForm=$("#auth-form");
 function showAuth(){
   app.hidden=true;auth.hidden=false;
   $("#auth-title").textContent="Admin sign in";
   $("#auth-description").textContent="Enter your administrator ID and password to continue.";
   $("#auth-password-label").textContent="Admin password";
   $("#auth-password").autocomplete="current-password";
   $("#auth-submit").textContent="Unlock admin panel";
 }
 function showAdmin(){auth.hidden=true;app.hidden=false;}
 if(storageGet(sessionStorage,"toolhub-admin-unlocked")==="yes")showAdmin();else showAuth();
 authForm.addEventListener("submit",e=>{
   e.preventDefault();const id=$("#auth-id").value,password=$("#auth-password").value,creds=getCredentials(),error=$("#auth-error");
   error.hidden=true;
   if(id!==creds.id||password!==creds.password){error.textContent="Incorrect admin ID or password.";error.hidden=false;return}
   storageSet(sessionStorage,"toolhub-admin-unlocked","yes");showAdmin();
 });
 try{
   const response=await fetch("../data/tools.json?adminv=20261022-4",{cache:"no-store"});
   if(response.ok){const hosted=await response.json();const errors=API.validateManifest(hosted);if(!errors.length){data=API.clone(hosted);hostedManifestString=JSON.stringify(hosted);}else notice("Hosted tools.json has validation errors. Restore a valid manifest before publishing.","notice-error");}
 }catch(_){notice("Could not load the hosted manifest. Showing the built-in starter data; check the data/tools.json path.","notice-error")}
 try {
   const draftRaw = localStorage.getItem(MANIFEST_DRAFT_KEY);
   if (draftRaw) {
     const saved = JSON.parse(draftRaw);
     const candidate = saved.manifest || saved;
     const errors = API.validateManifest(candidate);
     if (errors.length) {
       notice("A saved local draft is invalid and was not loaded. Export a backup or discard it after review.", "notice-error");
     } else if (saved.baseManifest && hostedManifestString && saved.baseManifest === hostedManifestString) {
       data = API.clone(candidate);
     } else {
       notice("A local draft exists, but it may be based on an older hosted manifest. It was not loaded automatically. Open Publish Changes and use Restore saved draft only if you want to recover it.", "notice-error");
     }
   }
 } catch (_) {
   notice("The saved local draft could not be read. It was left untouched; use backup/import or discard it after review.", "notice-error");
 }
 const saved=storageGet(localStorage,"toolhub-theme")||"system";document.documentElement.dataset.theme=saved==="system"?(matchMedia("(prefers-color-scheme: light)").matches?"light":"dark"):saved;
 $("#admin-theme-toggle").addEventListener("click",()=>{const current=storageGet(localStorage,"toolhub-theme")||"system",next=current==="system"?"dark":current==="dark"?"light":"system";storageSet(localStorage,"toolhub-theme",next);document.documentElement.dataset.theme=next==="system"?(matchMedia("(prefers-color-scheme: light)").matches?"light":"dark"):next});
 $$(".sidebar-link").forEach(b=>b.addEventListener("click",()=>setView(b.dataset.view)));$$("[data-go]").forEach(b=>b.addEventListener("click",()=>setView(b.dataset.go)));
 $("#quick-add-tool").addEventListener("click",()=>openTool());$("#add-tool-button").addEventListener("click",()=>openTool());$("#add-section-button").addEventListener("click",()=>openSection());
 $("#tool-form").addEventListener("submit",toolFormSubmit);$("#section-form").addEventListener("submit",sectionFormSubmit);
 $$("[data-close]").forEach(b=>b.addEventListener("click",closeEditor));
 $("#admin-tool-search").addEventListener("input",renderTools);$("#admin-status-filter").addEventListener("change",renderTools);
 $("#settings-form").addEventListener("submit",e=>{e.preventDefault();const f=e.currentTarget;data.site={...data.site,name:f.elements.name.value.trim(),tagline:f.elements.tagline.value.trim(),defaultTheme:f.elements.defaultTheme.value,footerDescription:f.elements.footerDescription.value.trim(),contactEmail:f.elements.contactEmail.value.trim()};changed("Site settings saved as a local draft. Export tools.json and upload it to publish.")});
 $("#security-form").addEventListener("submit",handleSecuritySubmit);
 $("#export-json").addEventListener("click",exportManifest);
 $("#discard-draft").addEventListener("click",()=>{try{if(!storageRemove(localStorage,MANIFEST_DRAFT_KEY)){toast("Browser storage could not be cleared. Check browser privacy settings.","error");return}toast("Local draft removed. Reloading the hosted manifest.","success");location.reload()}catch(_){toast("Browser storage could not be cleared. Check browser privacy settings.","error")}});$("#restore-draft").addEventListener("click",()=>{try{const raw=storageGet(localStorage,MANIFEST_DRAFT_KEY);if(!raw){toast("No saved local draft was found.","error");return}const saved=JSON.parse(raw),candidate=saved.manifest||saved,errors=API.validateManifest(candidate);if(errors.length){toast("Draft cannot be restored: "+errors.slice(0,3).join(" "),"error");return}data=API.clone(candidate);changedAt=[];changed("Saved draft restored intentionally. Review it and validate before exporting.");setView("publish")}catch(_){toast("Saved draft could not be restored.","error")}});$("#download-backup").addEventListener("click",()=>download("tools-backup.json",JSON.stringify(data,null,2)));
 $("#import-json").addEventListener("change",e=>importManifest(e.target.files[0]));
 $("#tool-form").addEventListener("reset",()=>{$("#tool-form").elements.id.dataset.edited="false"});
 renderAll();setView("overview");
}
document.addEventListener("DOMContentLoaded",init);
})();
